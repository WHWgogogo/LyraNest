@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================================
echo 正在打开 LyraNest 运行日志 (lyranest.log) ...
echo ============================================================
if not exist "lyranest.log" (
    echo [提示] 尚未发现日志文件 lyranest.log。
    echo 如果服务刚启动，请稍等片刻或确认 lyranest-server.exe 正在运行。
    echo.
    pause
    exit /b
)
start notepad.exe lyranest.log
