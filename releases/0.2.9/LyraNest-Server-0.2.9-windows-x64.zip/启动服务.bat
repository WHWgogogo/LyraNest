@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ============================================================
echo 正在后台启动 LyraNest 服务端 (http://localhost:8080) ...
echo ============================================================
start "" lyranest-server.exe
