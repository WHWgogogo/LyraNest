@echo off
cd /d "%~dp0"
echo ============================================================
echo Starting LyraNest Server on http://localhost:8080 ...
echo ============================================================
start "" lyranest-server.exe
