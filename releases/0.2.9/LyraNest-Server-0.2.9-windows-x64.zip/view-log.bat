@echo off
cd /d "%~dp0"
if not exist "lyranest.log" (
    echo [Notice] Log file lyranest.log does not exist yet.
    echo Please make sure lyranest-server.exe has started.
    pause
    exit /b
)
start notepad.exe lyranest.log
