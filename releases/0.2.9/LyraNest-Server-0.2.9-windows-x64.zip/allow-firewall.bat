@echo off
chcp 65001 >nul
echo ============================================================
echo   LyraNest Windows 服务端 - 一键配置防火墙放行规则
echo ============================================================
echo.
echo [提示] 正在检查并请求系统管理员权限...
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    echo [提示] 正在请求提升为管理员权限，请在弹窗中选择【是】...
    powershell -NoProfile -ExecutionPolicy Bypass -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)
cd /d "%~dp0"
echo.
echo [1/2] 正在放行程序: %~dp0lyranest-server.exe (所有网络类型)...
netsh advfirewall firewall delete rule name="LyraNest Server (App)" >nul 2>&1
netsh advfirewall firewall add rule name="LyraNest Server (App)" dir=in action=allow program="%~dp0lyranest-server.exe" enable=yes profile=any >nul 2>&1

echo [2/2] 正在放行 TCP 端口 8080 (所有网络类型)...
netsh advfirewall firewall delete rule name="LyraNest Server (Port 8080)" >nul 2>&1
netsh advfirewall firewall add rule name="LyraNest Server (Port 8080)" dir=in action=allow protocol=TCP localport=8080 enable=yes profile=any >nul 2>&1

echo.
echo ============================================================
echo [成功] 防火墙入站规则已添加完成！
echo 手机/平板/车机等局域网设备现已可正常连接。
echo ============================================================
echo.
pause
